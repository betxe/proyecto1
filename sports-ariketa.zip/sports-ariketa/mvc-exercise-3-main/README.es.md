# MVC Exercise 3

[eu](README.md) | [es](README.es.md) | [en](README.en.md)

En este ejercicio hemos añadido un **controller**, un **filter**, clases de **Service & Repository** y diferentes **views** para hacer un **CRUD** (Create/Read/Update/Delete) para el tipo de contenido **NewsItems**.

## Explicaciones

Podemos ver que el JavaBean de NewsItem JavaBean tiene la fecha de tipo **java.util.Date**, lang de tipo **java.util.Locale** u el autor de tipo **User**, pero en la base de datos son timestamp, String e **int**.

```java
// NewsItem.java
private Date date;
private Locale lang;
private User author;
```

```sql
/* mvc_exercise.db news_item table definition */
    date       timestamp default CURRENT_TIMESTAMP not null,
    lang       TEXT      default NULL,
    authorId   INTEGER                             not null
        references main.user
```
**¿Por qué?** En la base de datos authorId será un foreign key, por lo tanto, estará relacionada con otra tabla. Al trabajar con objetos, lo más lógico es relacionar el authorId con el usuario, y así, podemos por ejemplo conseguir el nombre de usuario del autor de una forma fácil.

¿Cómo los transformamos? No aparecen en el formulario de las noticias:

* Se puede usar la fecha de cuando se cree la noticia, usando la fecha del sistema.
* El autor se puede conseguir de la sesión.
* Se puede usar el locale configurado cuando se crea la noticia (de FMT o de la petición).

### Fecha de la noticia

La columna `date` en la base de datos está configurada con un valor predeterminado de `CURRENT_TIMESTAMP`, lo que significa que registra automáticamente la fecha y hora actual cuando se crea un nuevo `NewsItem` si le pasamos el campo vacío (null).

```sql
    date       timestamp default CURRENT_TIMESTAMP not null,
```

Para cargar la fecha de la base de datos, podemos hacerlo así:

```java
// DaoNewsItemMySQL.java
...
    Timestamp ts = rs.getTimestamp("date");
    Date date = new Date(ts.getTime());
    newsItem.setDate(date);
...
```

Ahora podemos trabajar con código Java sin problemas.
¿Por qué hacemos eso? Mira el código de debajo.
Fuera de los Repository, no deberíamos usar nada que esté dentro de `java.sql`, por lo que lo transformamos en algo más *genérico*: `java.util`. Si en un futuro cambiamos a otra base de datos que no sea SQL, podrémos transformar esa fecha a `java.util.date` y nada fuera del Repository tendrá que cambiarse.

```java
import java.sql.Timestamp;
...
import java.util.Date;
```

### Autor de la noticia

A la hora de hacer un insert en la base de datos, solo guardaremos el ID:

```java
// NewsRepositorySQL.java
...
String sqlInsert = "INSERT INTO news_item (title,body,lang,authorId) VALUES(?,?,?,?)";
...
stm.setInt(4, newsItem.getAuthor().getUserId());
...
```

Al cargar una noticia de la base de datos, conseguiremos el authorId, y entonces, podremos usar `UserRepository` para cargar el usuario.

```java
// NewsRepositorySQL.java
...
int authorId = rs.getInt("authorId");
User author = userRepository.loadUser(authorId);
newsItem.setAuthor(author);
...
```

### ¿Cómo consigo el locale actual en un controlador?

Empezaremod definiendo un locale por defecto (defaultLocale), por si no conseguimos un locale de otro sitio.

Después intentaremos conseguirlo de FMT y si no lo conseguimos de la petición (request).

```java
// NewsItemController.java
...
private Locale getLocale(HttpServletRequest request, HttpSession session) {
    Locale defaultLocale = Locale.forLanguageTag("en-UK"); // Default locale.
    Locale fmtLocale = (Locale) Config.get(session, Config.FMT_LOCALE); // Locale from FMT library
    Locale browserLocale = request.getLocale(); // Browser locale

    if (fmtLocale == null && browserLocale == null)
        return defaultLocale;
    
    if (fmtLocale == null)
        return browserLocale;

    return fmtLocale;
}
```

Luego, lo podemos guardar en la base de datos como string de esta manera:

```java
// DaoNewsItemMySQL.java
...
String sqlInsert = "INSERT INTO news_item (title,body,lang,authorId) VALUES(?,?,?,?)";
...
stm.setString(3, newsItem.getLang().getLanguage());
...
```

Para cargar solo las noticias de un idioma:

```java
// NewsRepositorySQL.java
...
String sqlQuery = "SELECT * FROM news_item WHERE lang=?";
String languageTag = locale.getLanguage();
...
try {
    stm = connection.prepareStatement(sqlQuery);
    stm.setString(1, languageTag);
    rs = stm.executeQuery();
    ...
```

Para mostrar el idioma de una noticia en un fichero JSP:

```jsp
<!-- news_item.jsp -->
${requestScope.newsItem.lang.language}
```

Como lo usamos con mensajes FMT (para que un idioma pueda aparecer en 3 idiomas:
"English", "Inglés", "Inglesa"

```jsp
<!-- news_item.jsp -->
<i><fmt:message key="language.${requestScope.newsItem.lang.language}"/></i>
```

### Formato de la fecha según el idioma
¿Cómo imprimimos el formato de la fecha según el idioma? Podemos usar la librería fmt para formatear la fecha.

```jsp
<!-- news_item.jsp -->
...
<fmt:formatDate value="${requestScope.newsItem.date}" type="both" />
...
```

> `type="both"` mostrará la fecha y la hora en el formato del idioma.

### Filtrar noticias por autor

¿Cómo comprobamos si el usuario es el autor de la noticia durante el filtrado? Hemos añadido ese caso de uso a `NewsService` y lo hemos usado en `NewsFilter`.


```java
// NewsService.java
...
@ApplicationScoped
public class NewsService {
	@Inject
	private NewsRepository repository;

    public boolean checkNewsItemAuthor(int newsItemId, int userId) {
        NewsItem newsItem = repository.loadNewsItem(newsItemId);
        if (newsItem == null) {
            // Guard clause
            return false;
        }

        return newsItem.getAuthor().getUserId() == userId;
    }
    ...
}
```

```java
// NewsFilter.java
...
@WebFilter("/news/*")
public class NewsFilter implements Filter {
    ...
    @Inject
    NewsService newsService;
    ...
    private int filterModification(HttpSession session) {
        User user = (User) session.getAttribute("user");
        int newsItemId = controllerHelper.getId();

        ...

        if (!newsService.checkNewsItemAuthor(newsItemId, user.getUserId())) {
            // Guard clause
            logger.error("Session user is not the author.");
            session.setAttribute("error", "error.403.user_not_author");
            return HttpServletResponse.SC_FORBIDDEN;
        }

        logger.debug("Session user is the author.");
        return HttpServletResponse.SC_OK;
    }
```

### Mostrar lista de noticias por idioma

Teníamos 2 opciones para mostrar solo noticias en un idioma:

1. Cargar todas las noticias de la base de datos y filtrarlas en Java (en la vista, el controlador o el servicio).
2. Filtrar las noticias en la base de datos (más eficiente).

Para implementar la 2ª opción, tenemos que pasar el idioma al cargar la lista de noticias:

```java
// NewsController.java
...

    /**
     * Default value if something is not correct or user wants to list NewsItems.
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    private void listNews(HttpServletRequest request, HttpServletResponse response) {
        Locale locale = this.getLocale(request, session);

        ArrayList<NewsItem> news = newsService.loadAllNewsItems(locale);
        ...
    }
    ...
```

```java
// NewsService.java
...
@ApplicationScoped
public class NewsService {
	@Inject
	private NewsRepository repository;
    ...
    public ArrayList<NewsItem> loadAllNewsItems(Locale locale) {
        return repository.loadNews(locale);
    }
    ...
}
```

```java
// NewsRepositorySQL.java
    ...
    @Override
    public ArrayList<NewsItem> loadNews(Locale locale) {
        ...
        String sqlQuery = "SELECT * FROM news_item WHERE lang=?";
        String languageTag = locale.getLanguage();
        logger.debug("Display Language:" + locale.getDisplayLanguage());
        logger.debug("Language:" + locale.getLanguage());
        logger.debug("LanguageTag:" + locale.toLanguageTag());

        ...
        try {
            stm = connection.prepareStatement(sqlQuery);
            stm.setString(1, languageTag);
            rs = stm.executeQuery();
            while (rs.next()) {
                newsItem = new NewsItem();
                ...
                String langStr = rs.getString("lang");
                Locale lang = Locale.forLanguageTag(langStr);
                newsItem.setLang(lang);
                ...
                newsItems.add(newsItem);
            }
            ...
        }
        ...
        return newsItems;
    }
```