package edu.mondragon.webeng1.mvc_exercise.domain.sport.repository;

import java.lang.invoke.MethodHandles;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import edu.mondragon.webeng1.mvc_exercise.config.SQLConfig;
import edu.mondragon.webeng1.mvc_exercise.domain.sport.model.Sport;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class SportRepositorySQL implements SportRepository{
    private final static Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    @Inject
    private SQLConfig sqlConfig;

    @Override
    public Sport insertSport(Sport Sport) {
        Sport retSport = null;

        String sqlInsert = "INSERT INTO sport_result (team1Name,team1Result,team2Name,team2Result) VALUES(?,?,?,?)";

        Connection connection = sqlConfig.connect();
        PreparedStatement stm = null;
        try {
            stm = connection.prepareStatement(sqlInsert, Statement.RETURN_GENERATED_KEYS);
            stm.setString(1, Sport.getTeam1Name());
            stm.setInt(2, Sport.getTeam1Result());
            stm.setString(3, Sport.getTeam2Name());
            stm.setInt(4, Sport.getTeam2Result());
            logger.debug(stm.toString());
            if (stm.executeUpdate() > 0) {
                // Get the ID
                try (ResultSet generatedKeys = stm.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        Sport.setSportResultId(generatedKeys.getInt(1));
                    } else {
                        throw new SQLException("Creating Sport failed, no ID obtained.");
                    }
                }
                retSport = Sport;
            } else {
                throw new SQLException("Creating Sport failed, no rows affected.");
            }
        } catch (SQLException e) {
            logger.error(sqlInsert, e);
        }
        sqlConfig.disconnect(connection, stm);
        return retSport;
    }

    @Override
    public Sport loadSport(int sportResultId) {
        String sqlQuery = "SELECT * FROM sport_result WHERE sportResultId=?";
        Sport Sport = null;
        Connection connection = sqlConfig.connect();
        PreparedStatement stm = null;
        try {
            stm = connection.prepareStatement(sqlQuery);
            stm.setInt(1, sportResultId);
            logger.debug(stm.toString());
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                Sport = new Sport();

                Sport.setSportResultId(rs.getInt("sportResultId"));
                Sport.setTeam1Name(rs.getString("team1Name"));
                Sport.setTeam1Result(rs.getInt("team1Result"));
                Sport.setTeam2Name(rs.getString("team2Name"));
                Sport.setTeam2Result(rs.getInt("team2Result"));;
            }
        } catch (SQLException e) {
            logger.error("Error loading sport result "+sportResultId, e);
        }
        sqlConfig.disconnect(connection, stm);
        return Sport;
    }

    @Override
    public ArrayList<Sport> loadSports() {
        ArrayList<Sport> Sports = new ArrayList<Sport>();
        Connection connection = sqlConfig.connect();
        String sqlQuery = "SELECT * FROM sport_result";
      
        ResultSet rs = null;
        PreparedStatement stm = null;
        Sport Sport = null;
        try {
            stm = connection.prepareStatement(sqlQuery);
            rs = stm.executeQuery();
            while (rs.next()) {
                Sport = new Sport();

                Sport.setSportResultId(rs.getInt("sportResultId"));
                Sport.setTeam1Name(rs.getString("team1Name"));
                Sport.setTeam1Result(rs.getInt("team1Result"));
                Sport.setTeam2Name(rs.getString("team2Name"));
                Sport.setTeam2Result(rs.getInt("team2Result"));;

                Sports.add(Sport);
            }
        } catch (SQLException e) {
            logger.error("Error loading sports items ", e);
        }
        sqlConfig.disconnect(connection, stm);
        return Sports;
    }

    @Override
    public Sport updateSport(Sport Sport) {
        Sport retSport = null;
        String sqlUpdate = "UPDATE sport_result SET team1Name=?, team1Result=?, team2Name=?, team2Result=? WHERE sportResultId=?";

        Connection connection = sqlConfig.connect();
        PreparedStatement stm = null;
        try {
            stm = connection.prepareStatement(sqlUpdate);
            stm.setString(1, Sport.getTeam1Name());
            stm.setInt(2, Sport.getTeam1Result());
            stm.setString(3, Sport.getTeam2Name());
            stm.setInt(4, Sport.getTeam2Result());

            if (stm.executeUpdate() < 1) {
                Sport.setSportResultId(0);
            }
            retSport = Sport;
        } catch (SQLException e) {
            logger.error("Error updating news item "+Sport.getSportResultId(), e);
        }
        sqlConfig.disconnect(connection, stm);
        return retSport;
    }

    @Override
    public boolean deleteSport(Integer sportResultId) {

        boolean ret = false;
        String sqlDelete = "DELETE FROM sport_result WHERE sportResultId=?";
        Connection connection = sqlConfig.connect();
        PreparedStatement stm = null;
        try {
            stm = connection.prepareStatement(sqlDelete);
            stm.setInt(1, sportResultId);

            if (stm.executeUpdate() > 0) {
                ret = true;
            } else {
                throw new SQLException("Deleting Sport failed, no rows affected.");
            }
        } catch (SQLException e) {
            logger.error("Error deleting Sport "+sportResultId, e);

        }
        sqlConfig.disconnect(connection, stm);
        return ret;
    }

}
