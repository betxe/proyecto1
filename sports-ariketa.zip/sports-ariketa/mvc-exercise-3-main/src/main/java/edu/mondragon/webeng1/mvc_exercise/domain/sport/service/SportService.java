package edu.mondragon.webeng1.mvc_exercise.domain.sport.service;

import java.util.ArrayList;
import edu.mondragon.webeng1.mvc_exercise.domain.sport.model.Sport;
import edu.mondragon.webeng1.mvc_exercise.domain.sport.repository.SportRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class SportService {
    @Inject
	private SportRepository repository;

    public Sport createSport(Sport Sport) {
        return repository.insertSport(Sport);
    }

    public Sport loadSport(int SportId) {
        return repository.loadSport(SportId);
    }

    public ArrayList<Sport> loadAllSports() {
        return repository.loadSports();
    }

    public Sport saveSport(Sport Sport) {
        Sport retSport;
        if (Sport.getSportResultId() == null || Sport.getSportResultId() == 0) {
            retSport = repository.insertSport(Sport);
        } else {
            retSport = repository.updateSport(Sport);
        }
        return retSport;
    }

    public boolean deleteSport(Integer SportId) {
        return repository.deleteSport(SportId);
    }

}
