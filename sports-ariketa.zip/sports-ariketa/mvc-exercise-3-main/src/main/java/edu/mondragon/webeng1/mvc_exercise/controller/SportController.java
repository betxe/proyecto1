package edu.mondragon.webeng1.mvc_exercise.controller;

import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import edu.mondragon.webeng1.mvc_exercise.domain.sport.model.Sport;
import edu.mondragon.webeng1.mvc_exercise.domain.sport.service.SportService;
import edu.mondragon.webeng1.mvc_exercise.helper.ControllerHelper;
import jakarta.inject.Inject;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "SportController", urlPatterns = { "/sport/*" })
public class SportController extends HttpServlet{
    private static final long serialVersionUID = 1L;
    private final static Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    @Inject
    private SportService sportService;

    @Inject
    private ControllerHelper controllerHelper;

    public SportController() {
        super();
    }

    // Maps actions name with actions methods
    private Map<String, BiConsumer<HttpServletRequest, HttpServletResponse>> getActionsMap = new HashMap<>() {{
        put("delete", SportController.this::deleteSport);
        put("create", SportController.this::showSportForm);
        put("edit", SportController.this::showSportForm);
        put("view", SportController.this::showSport);
        put("list", SportController.this::listSports);
    }};
    private Map<String, BiConsumer<HttpServletRequest, HttpServletResponse>> postActionsMap = new HashMap<>() {{
        put("create", SportController.this::createSport);
        put("edit", SportController.this::editSport);
    }};

/**
     * Executed if GET request.
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        logger.debug("Trying hot code reload");
        String action = controllerHelper.getAction();

        getActionsMap.getOrDefault(
            action,
            (req, res) -> listSports(request, response)
        ).accept(request, response);
    }

     /**
     * Executed if POST request.
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = controllerHelper.getAction();

        postActionsMap.getOrDefault(
            action,
            (req, res) -> listSports(request, response)
        ).accept(request, response);
    }

    /**
     * Default value if something is not correct or user wants to list Sports.
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    private void listSports(HttpServletRequest request, HttpServletResponse response) {
        ArrayList<Sport> sports = sportService.loadAllSports();
        request.setAttribute("sports", sports);

        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/WEB-INF/view/sport/sport_list.jsp");
        try {
            dispatcher.forward(request, response);
        } catch (ServletException | IOException e) {
            logger.error("Error dispatching sports view.", e);
        }
    }

        /**
     * Load sport and dispatch single sport view.
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    private void showSport(HttpServletRequest request, HttpServletResponse response) {
        Sport sport = sportService.loadSport(controllerHelper.getId());
        request.setAttribute("sport", sport);

        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/WEB-INF/view/sport/sport.jsp");
        try {
            dispatcher.forward(request, response);
        } catch (ServletException | IOException e) {
            logger.error("Error dispatching sport view.", e);
        }
    }

      /**
     * Dispatch sport form.
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    private void showSportForm(HttpServletRequest request, HttpServletResponse response) {
        int sportResultId = controllerHelper.getId();
        logger.debug("Show Sport Form: " + sportResultId);

        if(sportResultId > 0) {
            Sport sport = sportService.loadSport(sportResultId);
            request.setAttribute("sport", sport);
        }

        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/WEB-INF/view/sport/sport_form.jsp");
        try {
            dispatcher.forward(request, response);
        } catch (ServletException | IOException e) {
            logger.error("Error dispatching sport form view.", e);
        }
    }

     /**
     * Delete sport from Database and dispatch sport list.
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    private void deleteSport(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(true);
        int id = controllerHelper.getId();
        if (id != -1 && sportService.deleteSport(id)) {
            session.setAttribute("message", "message.deleteSport");
        } else {
            session.setAttribute("error", "error.deleteSport");
        }

        try {
            response.sendRedirect(request.getContextPath() + "/sport/list");
        } catch (IOException e) {
            logger.error("Error redirecting to sport list.", e);
        }
    }

    /**
     * Update sport and redirect to its view.
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    private void editSport(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(true);
        int id = controllerHelper.getId();
        Sport sport = sportService.loadSport(id);
        String retRedirectUrl;
        logger.debug("Edit Sport Item: " + id);


        sport.setTeam1Name(request.getParameter("team1Name"));
        sport.setTeam1Result(Integer.parseInt(request.getParameter("team1Result")));
        sport.setTeam2Name(request.getParameter("team2Name"));
        sport.setTeam2Result(Integer.parseInt(request.getParameter("team2Result")));
        sportService.saveSport(sport);


        if (sport.getSportResultId() <= 0) {
            // Guard clause
            session.setAttribute("error", "error.editSport");
            retRedirectUrl = request.getContextPath() + "/sport/" + id + "/edit";
        } else {
            session.setAttribute("message", "message.editSport");
            session.setAttribute("sport", sport);
            retRedirectUrl = request.getContextPath() + "/sport/" + id + "/view";
        }

        try {
            response.sendRedirect(retRedirectUrl);
        } catch (IOException e) {
            logger.error("Error redirecting after sport edition.", e);
        }
    }

    
    /**
     * Create sport and redirect to its view.
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    private void createSport(HttpServletRequest request, HttpServletResponse response){
        HttpSession session = request.getSession(true);
        Sport sport = new Sport();
        
        sport.setTeam1Name(request.getParameter("team1Name"));
        sport.setTeam1Result(Integer.parseInt(request.getParameter("team1Result")));
        sport.setTeam2Name(request.getParameter("team2Name"));
        sport.setTeam2Result(Integer.parseInt(request.getParameter("team2Result")));

        sportService.saveSport(sport);

        String redirectUrl = "";
        if (sport.getSportResultId() > 0) {
            // If news item has been created, redirect to its view.
            request.setAttribute("sport", sport);
            session.setAttribute("message", "message.createSport");
            redirectUrl = "/sport/" + sport.getSportResultId() + "/view";
        } else {
            // If news item could not be created, redirect to list news items.
            session.setAttribute("error", "error.createSport");
            redirectUrl = "/sport/list";
        }
        try {
            response.sendRedirect(request.getContextPath() + redirectUrl);
        } catch (IOException e) {
            logger.error("Error redirecting after sport creation.", e);
        }
    }

}