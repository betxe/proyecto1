package edu.mondragon.webeng1.mvc_exercise.domain.sport.repository;
import java.util.ArrayList;

import edu.mondragon.webeng1.mvc_exercise.domain.sport.model.Sport;

public interface SportRepository {
    public Sport insertSport(Sport sport);
    public Sport loadSport(int sportResultId);
	public ArrayList<Sport> loadSports();
	public Sport updateSport(Sport Sport);
	public boolean deleteSport(Integer sportResultId);
}
