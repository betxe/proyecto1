<!---------------------------->
<!-- multilingual suffix: en, es, eu -->
<!-- no suffix: eu -->
<!---------------------------->
<!-- [common] -->
# MVC Exercise 3

[eu](README.md) | [es](README.es.md) | [en](README.en.md)

<!-- [en] -->
In this exercise we have added a **controller**, a **filter**, **Service & Repository classes** and different **views** for making a **CRUD** (Create/Read/Update/Delete) for **NewsItems**.

<!-- [eu] -->
Ariketa honetan **controller** bat, **filter** bat, **Service & Repository** klaseak eta **view** ezberdinak gehitu ditugu **CRUD** (Create/Read/Update/Delete) bat egiteko **NewsItems** eduki motarentzako.

<!-- [es] -->
En este ejercicio hemos añadido un **controller**, un **filter**, clases de **Service & Repository** y diferentes **views** para hacer un **CRUD** (Create/Read/Update/Delete) para el tipo de contenido **NewsItems**.

<!-- [en] -->
## Explainations

We can see that NewsItem JavaBean has date as a **java.util.Date**, lang as a **java.util.Locale** and author as a **User**, but in the database they are timestamp, String and **int**.

<!-- [eu] -->
## Azalpenak

NewsItem JavaBean-ak data **java.util.Date** motatakoa duela ikusi dezakegu, lang **java.util.Locale** motatakoa eta autorea **User** motatakoa, baina datu basean timestamp, String eta **int** motatakoak dira.

<!-- [es] -->
## Explicaciones

Podemos ver que el JavaBean de NewsItem JavaBean tiene la fecha de tipo **java.util.Date**, lang de tipo **java.util.Locale** u el autor de tipo **User**, pero en la base de datos son timestamp, String e **int**.

<!-- [common] -->
```java
// NewsItem.java
private Date date;
private Locale lang;
private User author;
```

```sql
/* mvc_exercise.db news_item table definition */
    date       timestamp default CURRENT_TIMESTAMP not null,
    lang       TEXT      default NULL,
    authorId   INTEGER                             not null
        references main.user
```
<!-- [en] -->
**Why?** In the database authorId will be a foreign key, so it is related to another table. When working with object, the most logic thing could be linking that authorId to the user, so then we could see, for example, the username of the author of a news item.

<!-- [eu] -->
**Zergatik?** Datu basean authorId foreign key bat izango da, beraz, beste taula batekin egongo da erlazionatuta. Objektuekin lan egiten dugunean, logikoena authorId hori erabiltzaile batekin eralzionatzea izango da, horrela, adibidez, autorearen erabiltzaile izena ere lortu ahal izango genuke era erraz batean.

<!-- [es] -->
**¿Por qué?** En la base de datos authorId será un foreign key, por lo tanto, estará relacionada con otra tabla. Al trabajar con objetos, lo más lógico es relacionar el authorId con el usuario, y así, podemos por ejemplo conseguir el nombre de usuario del autor de una forma fácil.

<!-- [en] -->
How do we transform them? They do not have to appear in the creation/edition forms:

* Date will be the current date when creating the NewsItem.
* The autor with be the current user in session.
* Locale will be the current locale when creating the NewsItem (using FMT or request locale).

<!-- [eu] -->
Nola eraldatu ditzakegu? Ez dira formulategietan agertzen:

* Data berria sortzen deneko data gorde dezake, sistematik hartuta.
* Autorea momentuan sesioan dagoen erabiltzailetik hartu dezakegu.
* Momentuko Locale-a erabili dezakegu ere berria sortzerakoan (FMT localea edo eskaerako lokalea erabiliz).

<!-- [es] -->
¿Cómo los transformamos? No aparecen en el formulario de las noticias:

* Se puede usar la fecha de cuando se cree la noticia, usando la fecha del sistema.
* El autor se puede conseguir de la sesión.
* Se puede usar el locale configurado cuando se crea la noticia (de FMT o de la petición).

<!-- [en] -->
### NewsItem date

The `date` column in the database is configured with a default value of `CURRENT_TIMESTAMP`, meaning it automatically records the current date and time when a new `NewsItem` is created with null date.

<!-- [eu] -->
### Berriaren data

Datu-baseko `date` zutabea `CURRENT_TIMESTAMP` balio lehenetsiarekin konfiguratuta dago, hau da, automatikoki erregistratzen ditu uneko data eta ordua `NewsItem` berri bat sortzen denean, date hutsik pasatzen badiogunean (null).

<!-- [es] -->
### Fecha de la noticia

La columna `date` en la base de datos está configurada con un valor predeterminado de `CURRENT_TIMESTAMP`, lo que significa que registra automáticamente la fecha y hora actual cuando se crea un nuevo `NewsItem` si le pasamos el campo vacío (null).

<!-- [common] -->
```sql
    date       timestamp default CURRENT_TIMESTAMP not null,
```

<!-- [en] -->
In order to load that date from the database, we can do it like this:

<!-- [eu] -->
Datu basetik data kargatzeko, hau egin dezakegu:

<!-- [es] -->
Para cargar la fecha de la base de datos, podemos hacerlo así:

<!-- [common] -->
```java
// DaoNewsItemMySQL.java
...
    Timestamp ts = rs.getTimestamp("date");
    Date date = new Date(ts.getTime());
    newsItem.setDate(date);
...
```

<!-- [en] -->
Now we can work with regular java dates quite confortably.
Why do we do that? Look the code below.
Out of Repository, we should avoid using anyting inside `java.sql`, so instead we transform to something that is more *generic*: `java.util`. If in the future we change to another database that is not SQL, we could transofrm that data to `java.util.date` and nothing outside the Repository implementation will be modified.

<!-- [eu] -->
Orain java kode normalarekin lan egin dezakegu arazo gabe.
Zergatik egiten dugu hau? Ikusi azpiko kodea.
Repository-etatik kanpo, ez genuke `java.sql` pakete barruan dagoen ezer erabili beharko, beraz, zerbait *generikoagoan* bihurtzen dugu: `java.util`. Etorkizunean SQL ez den datu base bat erabiltzera aldatzen badugu, datu base horretako data ere `java.util.date` motara aldatu genezake, eta Repository-tik kanpoko ezer ez litzake aldatuko.

<!-- [es] -->
Ahora podemos trabajar con código Java sin problemas.
¿Por qué hacemos eso? Mira el código de debajo.
Fuera de los Repository, no deberíamos usar nada que esté dentro de `java.sql`, por lo que lo transformamos en algo más *genérico*: `java.util`. Si en un futuro cambiamos a otra base de datos que no sea SQL, podrémos transformar esa fecha a `java.util.date` y nada fuera del Repository tendrá que cambiarse.

<!-- [common] -->
```java
import java.sql.Timestamp;
...
import java.util.Date;
```

<!-- [en] -->
### News Item author

In order to insert the author in the database, we will store only the Id:

<!-- [eu] -->
### Berriaren autorea

Autorea datubasean gehitzerako orduan, IDa bakarrik gordeko dugu:

<!-- [es] -->
### Autor de la noticia

A la hora de hacer un insert en la base de datos, solo guardaremos el ID:

<!-- [common] -->
```java
// NewsRepositorySQL.java
...
String sqlInsert = "INSERT INTO news_item (title,body,lang,authorId) VALUES(?,?,?,?)";
...
stm.setInt(4, newsItem.getAuthor().getUserId());
...
```

<!-- [en] -->
When loading the newsItem from the database, we will get the authorId, and then, we can use `UserRepository` to load the entire user.

<!-- [eu] -->
Berria datu basetik kargatzerakoan, authorId jasoko dugu, eta gero, `UserRepository` erabiliko dugu erabiltzaile osoa kargatzeko.

<!-- [es] -->
Al cargar una noticia de la base de datos, conseguiremos el authorId, y entonces, podremos usar `UserRepository` para cargar el usuario.

<!-- [common] -->
```java
// NewsRepositorySQL.java
...
int authorId = rs.getInt("authorId");
User author = userRepository.loadUser(authorId);
newsItem.setAuthor(author);
...
```

<!-- [en] -->
### How to get current locale in a controller

We will start creating a defaultLocale, just in case everything else fails.

Then we will get the locale from FMT and browsers locale.

<!-- [eu] -->
### Nola lortu momentuko locale-a kontrolatzaile batetan

Defektuzko locale bat sortzen hasiko gara (defaultLocale), beste ezer ez badabil, hori erabiltzeko.

Gero, FMTko locale-a jasotzen saiatuko gara, eta ezin bada, eskaerako locale-a (request).

<!-- [es] -->
### ¿Cómo consigo el locale actual en un controlador?

Empezaremod definiendo un locale por defecto (defaultLocale), por si no conseguimos un locale de otro sitio.

Después intentaremos conseguirlo de FMT y si no lo conseguimos de la petición (request).

<!-- [common] -->
```java
// NewsItemController.java
...
private Locale getLocale(HttpServletRequest request, HttpSession session) {
    Locale defaultLocale = Locale.forLanguageTag("en-UK"); // Default locale.
    Locale fmtLocale = (Locale) Config.get(session, Config.FMT_LOCALE); // Locale from FMT library
    Locale browserLocale = request.getLocale(); // Browser locale

    if (fmtLocale == null && browserLocale == null)
        return defaultLocale;
    
    if (fmtLocale == null)
        return browserLocale;

    return fmtLocale;
}
```

<!-- [en] -->
Then, we can store it as a string in the database this way:

<!-- [eu] -->
Gero datu basean string moduan gordetzeko:

<!-- [es] -->
Luego, lo podemos guardar en la base de datos como string de esta manera:

<!-- [common] -->
```java
// DaoNewsItemMySQL.java
...
String sqlInsert = "INSERT INTO news_item (title,body,lang,authorId) VALUES(?,?,?,?)";
...
stm.setString(3, newsItem.getLang().getLanguage());
...
```

<!-- [en] -->
In order to load just the newsItem in a locale:

<!-- [eu] -->
Hizkuntza bateko berriak bakarrik kargatzeko:

<!-- [es] -->
Para cargar solo las noticias de un idioma:

<!-- [common] -->
```java
// NewsRepositorySQL.java
...
String sqlQuery = "SELECT * FROM news_item WHERE lang=?";
String languageTag = locale.getLanguage();
...
try {
    stm = connection.prepareStatement(sqlQuery);
    stm.setString(1, languageTag);
    rs = stm.executeQuery();
    ...
```

<!-- [en] -->
In order to show the language of a newsItem in a JSP file:

<!-- [eu] -->
Berri baten hizkuntza bistaratzeko JSP fitxategi batetan:

<!-- [es] -->
Para mostrar el idioma de una noticia en un fichero JSP:

<!-- [common] -->
```jsp
<!-- news_item.jsp -->
${requestScope.newsItem.lang.language}
```

<!-- [en] -->
As we use it with FMT messages (language could be shown in 3 different languages:
<!-- [eu] -->
Hizkuntza FMT mezu batetan dugunez (hizkuntza bat hiru hizkuntzetan agertzeko:
<!-- [es] -->
Como lo usamos con mensajes FMT (para que un idioma pueda aparecer en 3 idiomas:
<!-- [common] -->
"English", "Inglés", "Inglesa"

```jsp
<!-- news_item.jsp -->
<i><fmt:message key="language.${requestScope.newsItem.lang.language}"/></i>
```

<!-- [en] -->
### Date formating according to the locale
How do we print the date format according to the locale? We can use fmt library to format the date.

<!-- [eu] -->
### Dataren formatua hizkuntza arabera
Nola inprimatu data bat formatu ezberdinetan hizkuntza arabera? FMT liburutegia erabil dezakegu data formatuagatik.

<!-- [es] -->
### Formato de la fecha según el idioma
¿Cómo imprimimos el formato de la fecha según el idioma? Podemos usar la librería fmt para formatear la fecha.

<!-- [common] -->
```jsp
<!-- news_item.jsp -->
...
<fmt:formatDate value="${requestScope.newsItem.date}" type="both" />
...
```

<!-- [en] -->
> `type="both"` will show the date and time in the format of the locale.

<!-- [eu] -->
> `type="both"` hizkuntzaren formatuan data eta ordua bistaratuko ditu.

<!-- [es] -->
> `type="both"` mostrará la fecha y la hora en el formato del idioma.

<!-- [en] -->
### Filtering NewsItem by author

How do we check if the user is the author of the news item during filtering? We have added that use case to `NewsService` and we have used it in `NewsFilter`.

<!-- [eu] -->
### Berriak autorearen arabera filtratzea

Nola egiaztatu erabiltzailea berriaren autorea den filtratzean? Kasu hori gehitu dugu `NewsService`-an eta `NewsFilter`-ean erabili dugu.

<!-- [es] -->
### Filtrar noticias por autor

¿Cómo comprobamos si el usuario es el autor de la noticia durante el filtrado? Hemos añadido ese caso de uso a `NewsService` y lo hemos usado en `NewsFilter`.

<!-- [common] -->

```java
// NewsService.java
...
@ApplicationScoped
public class NewsService {
	@Inject
	private NewsRepository repository;

    public boolean checkNewsItemAuthor(int newsItemId, int userId) {
        NewsItem newsItem = repository.loadNewsItem(newsItemId);
        if (newsItem == null) {
            // Guard clause
            return false;
        }

        return newsItem.getAuthor().getUserId() == userId;
    }
    ...
}
```

```java
// NewsFilter.java
...
@WebFilter("/news/*")
public class NewsFilter implements Filter {
    ...
    @Inject
    NewsService newsService;
    ...
    private int filterModification(HttpSession session) {
        User user = (User) session.getAttribute("user");
        int newsItemId = controllerHelper.getId();

        ...

        if (!newsService.checkNewsItemAuthor(newsItemId, user.getUserId())) {
            // Guard clause
            logger.error("Session user is not the author.");
            session.setAttribute("error", "error.403.user_not_author");
            return HttpServletResponse.SC_FORBIDDEN;
        }

        logger.debug("Session user is the author.");
        return HttpServletResponse.SC_OK;
    }
```

<!-- [en] -->
### Showing news list by language

We had 2 options in order to showing just news in a language:

1. Loading all news from the database and filtering them in Java (in the view, Controller or Service).
2. Filtering the news in the database (more efficient).

In order to implement the 2nd option, we have to pass the language when loading the list of news:

<!-- [eu] -->
### Berrien zerrenda hizkuntzaren arabera bistaratzen

Hizkuntza bateko berriak bakarrik bistaratzeko bi aukera ditugu:

1. Berri guztiak datu baseatik kargatzea eta Java-n filtratzea (bistan, kontrolatzailean edo zerbitzuan).
2. Berriak datu basean filtratzea (efizienteagoa).

Azkenengo aukera hori egiteko, hizkuntza pasatu behar dugu berrien zerrenda kargatzerakoan:

<!-- [es] -->
### Mostrar lista de noticias por idioma

Teníamos 2 opciones para mostrar solo noticias en un idioma:

1. Cargar todas las noticias de la base de datos y filtrarlas en Java (en la vista, el controlador o el servicio).
2. Filtrar las noticias en la base de datos (más eficiente).

Para implementar la 2ª opción, tenemos que pasar el idioma al cargar la lista de noticias:

<!-- [common] -->
```java
// NewsController.java
...

    /**
     * Default value if something is not correct or user wants to list NewsItems.
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    private void listNews(HttpServletRequest request, HttpServletResponse response) {
        Locale locale = this.getLocale(request, session);

        ArrayList<NewsItem> news = newsService.loadAllNewsItems(locale);
        ...
    }
    ...
```

```java
// NewsService.java
...
@ApplicationScoped
public class NewsService {
	@Inject
	private NewsRepository repository;
    ...
    public ArrayList<NewsItem> loadAllNewsItems(Locale locale) {
        return repository.loadNews(locale);
    }
    ...
}
```

```java
// NewsRepositorySQL.java
    ...
    @Override
    public ArrayList<NewsItem> loadNews(Locale locale) {
        ...
        String sqlQuery = "SELECT * FROM news_item WHERE lang=?";
        String languageTag = locale.getLanguage();
        logger.debug("Display Language:" + locale.getDisplayLanguage());
        logger.debug("Language:" + locale.getLanguage());
        logger.debug("LanguageTag:" + locale.toLanguageTag());

        ...
        try {
            stm = connection.prepareStatement(sqlQuery);
            stm.setString(1, languageTag);
            rs = stm.executeQuery();
            while (rs.next()) {
                newsItem = new NewsItem();
                ...
                String langStr = rs.getString("lang");
                Locale lang = Locale.forLanguageTag(langStr);
                newsItem.setLang(lang);
                ...
                newsItems.add(newsItem);
            }
            ...
        }
        ...
        return newsItems;
    }
```