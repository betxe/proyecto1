# MVC Exercise 3

[eu](README.md) | [es](README.es.md) | [en](README.en.md)

Ariketa honetan **controller** bat, **filter** bat, **Service & Repository** klaseak eta **view** ezberdinak gehitu ditugu **CRUD** (Create/Read/Update/Delete) bat egiteko **NewsItems** eduki motarentzako.

## Azalpenak

NewsItem JavaBean-ak data **java.util.Date** motatakoa duela ikusi dezakegu, lang **java.util.Locale** motatakoa eta autorea **User** motatakoa, baina datu basean timestamp, String eta **int** motatakoak dira.

```java
// NewsItem.java
private Date date;
private Locale lang;
private User author;
```

```sql
/* mvc_exercise.db news_item table definition */
    date       timestamp default CURRENT_TIMESTAMP not null,
    lang       TEXT      default NULL,
    authorId   INTEGER                             not null
        references main.user
```
**Zergatik?** Datu basean authorId foreign key bat izango da, beraz, beste taula batekin egongo da erlazionatuta. Objektuekin lan egiten dugunean, logikoena authorId hori erabiltzaile batekin eralzionatzea izango da, horrela, adibidez, autorearen erabiltzaile izena ere lortu ahal izango genuke era erraz batean.

Nola eraldatu ditzakegu? Ez dira formulategietan agertzen:

* Data berria sortzen deneko data gorde dezake, sistematik hartuta.
* Autorea momentuan sesioan dagoen erabiltzailetik hartu dezakegu.
* Momentuko Locale-a erabili dezakegu ere berria sortzerakoan (FMT localea edo eskaerako lokalea erabiliz).

### Berriaren data

Datu-baseko `date` zutabea `CURRENT_TIMESTAMP` balio lehenetsiarekin konfiguratuta dago, hau da, automatikoki erregistratzen ditu uneko data eta ordua `NewsItem` berri bat sortzen denean, date hutsik pasatzen badiogunean (null).

```sql
    date       timestamp default CURRENT_TIMESTAMP not null,
```

Datu basetik data kargatzeko, hau egin dezakegu:

```java
// DaoNewsItemMySQL.java
...
    Timestamp ts = rs.getTimestamp("date");
    Date date = new Date(ts.getTime());
    newsItem.setDate(date);
...
```

Orain java kode normalarekin lan egin dezakegu arazo gabe.
Zergatik egiten dugu hau? Ikusi azpiko kodea.
Repository-etatik kanpo, ez genuke `java.sql` pakete barruan dagoen ezer erabili beharko, beraz, zerbait *generikoagoan* bihurtzen dugu: `java.util`. Etorkizunean SQL ez den datu base bat erabiltzera aldatzen badugu, datu base horretako data ere `java.util.date` motara aldatu genezake, eta Repository-tik kanpoko ezer ez litzake aldatuko.

```java
import java.sql.Timestamp;
...
import java.util.Date;
```

### Berriaren autorea

Autorea datubasean gehitzerako orduan, IDa bakarrik gordeko dugu:

```java
// NewsRepositorySQL.java
...
String sqlInsert = "INSERT INTO news_item (title,body,lang,authorId) VALUES(?,?,?,?)";
...
stm.setInt(4, newsItem.getAuthor().getUserId());
...
```

Berria datu basetik kargatzerakoan, authorId jasoko dugu, eta gero, `UserRepository` erabiliko dugu erabiltzaile osoa kargatzeko.

```java
// NewsRepositorySQL.java
...
int authorId = rs.getInt("authorId");
User author = userRepository.loadUser(authorId);
newsItem.setAuthor(author);
...
```

### Nola lortu momentuko locale-a kontrolatzaile batetan

Defektuzko locale bat sortzen hasiko gara (defaultLocale), beste ezer ez badabil, hori erabiltzeko.

Gero, FMTko locale-a jasotzen saiatuko gara, eta ezin bada, eskaerako locale-a (request).

```java
// NewsItemController.java
...
private Locale getLocale(HttpServletRequest request, HttpSession session) {
    Locale defaultLocale = Locale.forLanguageTag("en-UK"); // Default locale.
    Locale fmtLocale = (Locale) Config.get(session, Config.FMT_LOCALE); // Locale from FMT library
    Locale browserLocale = request.getLocale(); // Browser locale

    if (fmtLocale == null && browserLocale == null)
        return defaultLocale;
    
    if (fmtLocale == null)
        return browserLocale;

    return fmtLocale;
}
```

Gero datu basean string moduan gordetzeko:

```java
// DaoNewsItemMySQL.java
...
String sqlInsert = "INSERT INTO news_item (title,body,lang,authorId) VALUES(?,?,?,?)";
...
stm.setString(3, newsItem.getLang().getLanguage());
...
```

Hizkuntza bateko berriak bakarrik kargatzeko:

```java
// NewsRepositorySQL.java
...
String sqlQuery = "SELECT * FROM news_item WHERE lang=?";
String languageTag = locale.getLanguage();
...
try {
    stm = connection.prepareStatement(sqlQuery);
    stm.setString(1, languageTag);
    rs = stm.executeQuery();
    ...
```

Berri baten hizkuntza bistaratzeko JSP fitxategi batetan:

```jsp
<!-- news_item.jsp -->
${requestScope.newsItem.lang.language}
```

Hizkuntza FMT mezu batetan dugunez (hizkuntza bat hiru hizkuntzetan agertzeko:
"English", "Inglés", "Inglesa"

```jsp
<!-- news_item.jsp -->
<i><fmt:message key="language.${requestScope.newsItem.lang.language}"/></i>
```

### Dataren formatua hizkuntza arabera
Nola inprimatu data bat formatu ezberdinetan hizkuntza arabera? FMT liburutegia erabil dezakegu data formatuagatik.

```jsp
<!-- news_item.jsp -->
...
<fmt:formatDate value="${requestScope.newsItem.date}" type="both" />
...
```

> `type="both"` hizkuntzaren formatuan data eta ordua bistaratuko ditu.

### Berriak autorearen arabera filtratzea

Nola egiaztatu erabiltzailea berriaren autorea den filtratzean? Kasu hori gehitu dugu `NewsService`-an eta `NewsFilter`-ean erabili dugu.


```java
// NewsService.java
...
@ApplicationScoped
public class NewsService {
	@Inject
	private NewsRepository repository;

    public boolean checkNewsItemAuthor(int newsItemId, int userId) {
        NewsItem newsItem = repository.loadNewsItem(newsItemId);
        if (newsItem == null) {
            // Guard clause
            return false;
        }

        return newsItem.getAuthor().getUserId() == userId;
    }
    ...
}
```

```java
// NewsFilter.java
...
@WebFilter("/news/*")
public class NewsFilter implements Filter {
    ...
    @Inject
    NewsService newsService;
    ...
    private int filterModification(HttpSession session) {
        User user = (User) session.getAttribute("user");
        int newsItemId = controllerHelper.getId();

        ...

        if (!newsService.checkNewsItemAuthor(newsItemId, user.getUserId())) {
            // Guard clause
            logger.error("Session user is not the author.");
            session.setAttribute("error", "error.403.user_not_author");
            return HttpServletResponse.SC_FORBIDDEN;
        }

        logger.debug("Session user is the author.");
        return HttpServletResponse.SC_OK;
    }
```

### Berrien zerrenda hizkuntzaren arabera bistaratzen

Hizkuntza bateko berriak bakarrik bistaratzeko bi aukera ditugu:

1. Berri guztiak datu baseatik kargatzea eta Java-n filtratzea (bistan, kontrolatzailean edo zerbitzuan).
2. Berriak datu basean filtratzea (efizienteagoa).

Azkenengo aukera hori egiteko, hizkuntza pasatu behar dugu berrien zerrenda kargatzerakoan:

```java
// NewsController.java
...

    /**
     * Default value if something is not correct or user wants to list NewsItems.
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    private void listNews(HttpServletRequest request, HttpServletResponse response) {
        Locale locale = this.getLocale(request, session);

        ArrayList<NewsItem> news = newsService.loadAllNewsItems(locale);
        ...
    }
    ...
```

```java
// NewsService.java
...
@ApplicationScoped
public class NewsService {
	@Inject
	private NewsRepository repository;
    ...
    public ArrayList<NewsItem> loadAllNewsItems(Locale locale) {
        return repository.loadNews(locale);
    }
    ...
}
```

```java
// NewsRepositorySQL.java
    ...
    @Override
    public ArrayList<NewsItem> loadNews(Locale locale) {
        ...
        String sqlQuery = "SELECT * FROM news_item WHERE lang=?";
        String languageTag = locale.getLanguage();
        logger.debug("Display Language:" + locale.getDisplayLanguage());
        logger.debug("Language:" + locale.getLanguage());
        logger.debug("LanguageTag:" + locale.toLanguageTag());

        ...
        try {
            stm = connection.prepareStatement(sqlQuery);
            stm.setString(1, languageTag);
            rs = stm.executeQuery();
            while (rs.next()) {
                newsItem = new NewsItem();
                ...
                String langStr = rs.getString("lang");
                Locale lang = Locale.forLanguageTag(langStr);
                newsItem.setLang(lang);
                ...
                newsItems.add(newsItem);
            }
            ...
        }
        ...
        return newsItems;
    }
```