# MVC Exercise 3

[eu](README.md) | [es](README.es.md) | [en](README.en.md)

In this exercise we have added a **controller**, a **filter**, **Service & Repository classes** and different **views** for making a **CRUD** (Create/Read/Update/Delete) for **NewsItems**.

## Explainations

We can see that NewsItem JavaBean has date as a **java.util.Date**, lang as a **java.util.Locale** and author as a **User**, but in the database they are timestamp, String and **int**.

```java
// NewsItem.java
private Date date;
private Locale lang;
private User author;
```

```sql
/* mvc_exercise.db news_item table definition */
    date       timestamp default CURRENT_TIMESTAMP not null,
    lang       TEXT      default NULL,
    authorId   INTEGER                             not null
        references main.user
```
**Why?** In the database authorId will be a foreign key, so it is related to another table. When working with object, the most logic thing could be linking that authorId to the user, so then we could see, for example, the username of the author of a news item.

How do we transform them? They do not have to appear in the creation/edition forms:

* Date will be the current date when creating the NewsItem.
* The autor with be the current user in session.
* Locale will be the current locale when creating the NewsItem (using FMT or request locale).

### NewsItem date

The `date` column in the database is configured with a default value of `CURRENT_TIMESTAMP`, meaning it automatically records the current date and time when a new `NewsItem` is created with null date.

```sql
    date       timestamp default CURRENT_TIMESTAMP not null,
```

In order to load that date from the database, we can do it like this:

```java
// DaoNewsItemMySQL.java
...
    Timestamp ts = rs.getTimestamp("date");
    Date date = new Date(ts.getTime());
    newsItem.setDate(date);
...
```

Now we can work with regular java dates quite confortably.
Why do we do that? Look the code below.
Out of Repository, we should avoid using anyting inside `java.sql`, so instead we transform to something that is more *generic*: `java.util`. If in the future we change to another database that is not SQL, we could transofrm that data to `java.util.date` and nothing outside the Repository implementation will be modified.

```java
import java.sql.Timestamp;
...
import java.util.Date;
```

### News Item author

In order to insert the author in the database, we will store only the Id:

```java
// NewsRepositorySQL.java
...
String sqlInsert = "INSERT INTO news_item (title,body,lang,authorId) VALUES(?,?,?,?)";
...
stm.setInt(4, newsItem.getAuthor().getUserId());
...
```

When loading the newsItem from the database, we will get the authorId, and then, we can use `UserRepository` to load the entire user.

```java
// NewsRepositorySQL.java
...
int authorId = rs.getInt("authorId");
User author = userRepository.loadUser(authorId);
newsItem.setAuthor(author);
...
```

### How to get current locale in a controller

We will start creating a defaultLocale, just in case everything else fails.

Then we will get the locale from FMT and browsers locale.

```java
// NewsItemController.java
...
private Locale getLocale(HttpServletRequest request, HttpSession session) {
    Locale defaultLocale = Locale.forLanguageTag("en-UK"); // Default locale.
    Locale fmtLocale = (Locale) Config.get(session, Config.FMT_LOCALE); // Locale from FMT library
    Locale browserLocale = request.getLocale(); // Browser locale

    if (fmtLocale == null && browserLocale == null)
        return defaultLocale;
    
    if (fmtLocale == null)
        return browserLocale;

    return fmtLocale;
}
```

Then, we can store it as a string in the database this way:

```java
// DaoNewsItemMySQL.java
...
String sqlInsert = "INSERT INTO news_item (title,body,lang,authorId) VALUES(?,?,?,?)";
...
stm.setString(3, newsItem.getLang().getLanguage());
...
```

In order to load just the newsItem in a locale:

```java
// NewsRepositorySQL.java
...
String sqlQuery = "SELECT * FROM news_item WHERE lang=?";
String languageTag = locale.getLanguage();
...
try {
    stm = connection.prepareStatement(sqlQuery);
    stm.setString(1, languageTag);
    rs = stm.executeQuery();
    ...
```

In order to show the language of a newsItem in a JSP file:

```jsp
<!-- news_item.jsp -->
${requestScope.newsItem.lang.language}
```

As we use it with FMT messages (language could be shown in 3 different languages:
"English", "Inglés", "Inglesa"

```jsp
<!-- news_item.jsp -->
<i><fmt:message key="language.${requestScope.newsItem.lang.language}"/></i>
```

### Date formating according to the locale
How do we print the date format according to the locale? We can use fmt library to format the date.

```jsp
<!-- news_item.jsp -->
...
<fmt:formatDate value="${requestScope.newsItem.date}" type="both" />
...
```

> `type="both"` will show the date and time in the format of the locale.

### Filtering NewsItem by author

How do we check if the user is the author of the news item during filtering? We have added that use case to `NewsService` and we have used it in `NewsFilter`.


```java
// NewsService.java
...
@ApplicationScoped
public class NewsService {
	@Inject
	private NewsRepository repository;

    public boolean checkNewsItemAuthor(int newsItemId, int userId) {
        NewsItem newsItem = repository.loadNewsItem(newsItemId);
        if (newsItem == null) {
            // Guard clause
            return false;
        }

        return newsItem.getAuthor().getUserId() == userId;
    }
    ...
}
```

```java
// NewsFilter.java
...
@WebFilter("/news/*")
public class NewsFilter implements Filter {
    ...
    @Inject
    NewsService newsService;
    ...
    private int filterModification(HttpSession session) {
        User user = (User) session.getAttribute("user");
        int newsItemId = controllerHelper.getId();

        ...

        if (!newsService.checkNewsItemAuthor(newsItemId, user.getUserId())) {
            // Guard clause
            logger.error("Session user is not the author.");
            session.setAttribute("error", "error.403.user_not_author");
            return HttpServletResponse.SC_FORBIDDEN;
        }

        logger.debug("Session user is the author.");
        return HttpServletResponse.SC_OK;
    }
```

### Showing news list by language

We had 2 options in order to showing just news in a language:

1. Loading all news from the database and filtering them in Java (in the view, Controller or Service).
2. Filtering the news in the database (more efficient).

In order to implement the 2nd option, we have to pass the language when loading the list of news:

```java
// NewsController.java
...

    /**
     * Default value if something is not correct or user wants to list NewsItems.
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    private void listNews(HttpServletRequest request, HttpServletResponse response) {
        Locale locale = this.getLocale(request, session);

        ArrayList<NewsItem> news = newsService.loadAllNewsItems(locale);
        ...
    }
    ...
```

```java
// NewsService.java
...
@ApplicationScoped
public class NewsService {
	@Inject
	private NewsRepository repository;
    ...
    public ArrayList<NewsItem> loadAllNewsItems(Locale locale) {
        return repository.loadNews(locale);
    }
    ...
}
```

```java
// NewsRepositorySQL.java
    ...
    @Override
    public ArrayList<NewsItem> loadNews(Locale locale) {
        ...
        String sqlQuery = "SELECT * FROM news_item WHERE lang=?";
        String languageTag = locale.getLanguage();
        logger.debug("Display Language:" + locale.getDisplayLanguage());
        logger.debug("Language:" + locale.getLanguage());
        logger.debug("LanguageTag:" + locale.toLanguageTag());

        ...
        try {
            stm = connection.prepareStatement(sqlQuery);
            stm.setString(1, languageTag);
            rs = stm.executeQuery();
            while (rs.next()) {
                newsItem = new NewsItem();
                ...
                String langStr = rs.getString("lang");
                Locale lang = Locale.forLanguageTag(langStr);
                newsItem.setLang(lang);
                ...
                newsItems.add(newsItem);
            }
            ...
        }
        ...
        return newsItems;
    }
```